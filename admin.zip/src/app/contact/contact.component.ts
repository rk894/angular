import { Component, OnInit } from '@angular/core';
import {ContactService} from '../contact/contact.service';

@Component({
  selector: 'app-contact',
  templateUrl: './contact.component.html',
  styleUrls: ['./contact.component.css']
})
export class ContactComponent implements OnInit {

  data:any=[];

  constructor(private http:ContactService) { }

  ngOnInit() {

    return this.http.selectData().subscribe(res=>{
      this.data=res;
      // console.log(this.data);
    });
  }

}
