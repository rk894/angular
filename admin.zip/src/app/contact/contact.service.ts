import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';


@Injectable({
  providedIn: 'root'
})
export class ContactService {

  fetch="http://localhost/Angular_API/contact_fetch.php";

  constructor(private http:HttpClient) { }

  selectData()
  {
    return this.http.get(this.fetch);
  }
}
