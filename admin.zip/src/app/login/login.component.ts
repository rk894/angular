import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
import {FormGroup,FormBuilder,FormControl,Validator, Validators} from '@angular/forms';
import {LoginService} from '../login/login.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  myForm:FormGroup;

  result:any;

  constructor(private http : LoginService,
              private fb:FormBuilder,
              private router:Router) 
              { 

    // localStorage.removeItem('login');
    // console.log(localStorage.getItem('login'));

  }

  ngOnInit() {

    this.myForm=this.fb.group({

      email:['',[Validators.required]],
      pass:['',[Validators.required]]

    });

    // console.log(localStorage.getItem('login'));

  }

  get email(){ return this.myForm.get("email").value}
  get pass(){ return this.myForm.get('pass').value}

  onSubmit()
  {
    // console.log(this.myForm.value);
    return this.http.dataFetch(this.myForm.value).subscribe(res=>{
      this.result=res;

      if(this.result=='success')
      {
         localStorage.setItem('login','rahul');
         this.myForm.reset();
         this.router.navigate(['/home']);
        // console.log(localStorage.getItem('login'));

           
      }
      else{
           alert('incorect password');
        // console.log(this.result=res);

      }
     
       

    });
  }

 

}
