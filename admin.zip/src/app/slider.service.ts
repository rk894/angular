import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';


@Injectable({
  providedIn: 'root'
})
export class SliderService {

  url="http://localhost/Angular_API/image.php";
  url_blog="http://localhost/Angular_API/blog.php";

  constructor(private http:HttpClient) { }

  upload(data){
    return this.http.post(this.url,data);
  }

  upload_blog(data){
    return this.http.post(this.url_blog,data);
  }

 
}
