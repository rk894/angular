import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class BlogService {
  
  
  url="http://localhost/Angular_API/blogs.php";
  url_fetch="http://localhost/Angular_API/blog_fetch.php";
  url_fetch_data="http://localhost/Angular_API/blog_fetch_data.php?id=";
  url_delete="http://localhost/Angular_API/blog_delete.php?id=";

  update_blogs="http://localhost/Angular_API/update_blogs.php";

  constructor(private http:HttpClient) { }

  insertBlog(data){

    return this.http.post(this.url,data);

  }

  fetchBlog(){
    return this.http.get(this.url_fetch);
  }

  deleteBlog(id:number){
    return this.http.delete(this.url_delete+id);
  }

  fetchData(id:number){
    return this.http.get(this.url_fetch_data+id);

  }

  updateData(data){
    // console.log(data);
    return this.http.post(this.update_blogs,data);

  }

  
}
