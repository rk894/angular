import { Component, OnInit } from '@angular/core';
import {FormControl,FormGroup,Validators, FormBuilder} from '@angular/forms';
import {BlogService} from '../blog/blog.service';

@Component({
  selector: 'app-blog',
  templateUrl: './blog.component.html',
  styleUrls: ['./blog.component.css']
})
export class BlogComponent implements OnInit {

  constructor(private http:BlogService,private fb:FormBuilder) { }
  image="http://localhost/Angular_API/uploads/";
  n:number=1;
  bgcolor:any;
  icon:any;
  blog1:File=null;
  alert:boolean=false;
  dalert:boolean=false;
  myForm:FormGroup;
  data:any=[];

  update_alert:boolean=false;

  

  ngOnInit() {

    // this.update_alert=localStorage.getItem('update');
    if(localStorage.getItem('alert')=='update')
    {
       this.update_alert=true;
      //  localStorage.clear();
      setTimeout(()=>{
        localStorage.removeItem('alert');
        $("#h1").fadeOut();

      },2000);
    }
   

    this.myForm=this.fb.group({
      h1:['',[Validators.required]],
      d1:['',[Validators.required]],
      bimg1:['',[Validators.required]]
    });

    return this.http.fetchBlog().subscribe(res=>{
      this.data=res;
      // console.log(this.data);
    });

    

  }

  

  get h1(){return this.myForm.get('h1')}
  get d1(){return this.myForm.get('d1')}
  get bimg1(){return this.myForm.get('bimg1')}

  select1(event){
    if(event.target.files.length > 0)
    {
      this.blog1=event.target.files[0];
    }
  }

  blog_add(){

    const fd= new FormData();
    fd.append('img',this.blog1,this.blog1.name);
    fd.append('heading',this.myForm.get('h1').value);
    fd.append('desc',this.myForm.get('d1').value);
    fd.append('id','1');

    return this.http.insertBlog(fd).subscribe(res=>{
      this.myForm.reset();
      this.alert=true;
      this.ngOnInit();

      setTimeout(()=>{

        this.alert=false;

      },2000)
     
      

    });

    

    
   

  }


  deleteBlog(id:number){

    

    if(confirm('Are you sure to delete'))
    {
      return this.http.deleteBlog(id).subscribe(res=>{
        this.dalert=true;
        this.ngOnInit();
  
        setTimeout(()=>{
  
          this.dalert=false;
  
        },2000)
       
  
      });

    }

    
    
  }




}
