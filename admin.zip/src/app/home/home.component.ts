import { Component, OnInit } from '@angular/core';
import {FormGroup,FormControl,Validators,FormBuilder} from '@angular/forms';
import {SliderService} from '../slider.service';
import * as $ from "jquery";





@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

 


  image:File=null;
  image2_file:File=null;
  image3_file:File=null;
  bgcolor:any;
  icon:any;
  blog1:File=null;
  myForm:FormGroup;


  
 

  constructor(private http:SliderService,private fb:FormBuilder) { }

  ngOnInit() {

    // $(document).ready(function(){
     
    // });

    this.myForm=this.fb.group({
      h1:['',[Validators.required]],
      d1:['',[Validators.required]],
      bimg1:['',[Validators.required]]
    });

  }

  get h1(){return this.myForm.get('h1')}
  get d1(){return this.myForm.get('d1')}
  get bimg1(){return this.myForm.get('bimg1')}

 

  

  image1(event){
  
    
    if(event.target.files.length > 0)
    {
      this.image=<File>event.target.files[0];
    }

    
     
  }

  clk1(){

    // console.log(this.image)
    if(this.image !=null)
    {
      const fd=new FormData();

      fd.append('img',this.image,this.image.name);
      fd.append('id','1');
    
  
      return this.http.upload(fd).subscribe(res=>{
        
  
        $("#abc").val('');
        this.snackbar('success','Successfully Updated !!');
        this.image =null;
      
      
      });

    }
   
  }

  image2(event){

    // console.log(event.target.files[0]);
    if(event.target.files.length > 0)
    {
      this.image2_file=event.target.files[0];
    }
  
  }

  clk2(){

    if(this.image2_file !=null)
    {
      const fd=new FormData();
      fd.append('img',this.image2_file,this.image2_file.name);
      fd.append('id','2');
      return this.http.upload(fd).subscribe(res=>{
       
        $("#abc2").val('');
        this.snackbar('primary','Successfully Updated !!');
        this.image2_file=null;
      });
    }
    
  }


  image3(event){
    if(event.target.files.length > 0)
    {
      this.image3_file=event.target.files[0];
    }
   
  }

  clk3(){

    if(this.image3_file !=null)
    {
      const fd= new FormData();
      fd.append('img',this.image3_file,this.image3_file.name);
      fd.append('id','3');

      
  
      return this.http.upload(fd).subscribe(res=>{
       
        $("#abc3").val('');
        this.snackbar('info','Successfully Updated !!');
        this.image3_file=null;
      });

    }
   
  }


  snackbar(color,text) { 
  
    if (color=="primary") { color="#fff"; this.bgcolor="#007bff";  this.icon='<i class="fa fa-bell"></i>';
  }else if(color=="success"){ color="#fff"; this.bgcolor="#4CAF50"; this.icon='<i class="fa fa-check"></i>';
  }else if(color=="info"){color="#fff"; this.bgcolor="#17a2b8"; this.icon='<i class="fa fa-info-circle"></i>';
  }else if(color=="warning"){ 
           color="#fff"; this.bgcolor="#ffc107"; this.icon='<i class="fa fa-exclamation"></i>';
  }else if(color=="danger"){
  	       color="#fff"; this.bgcolor="#dc3545"; this.icon='<i class="fa fa-exclamation-triangle"></i>';
  }else{   color="#fff"; this.bgcolor="#333"; this.icon='<i class="fa fa-bell"></i>'; }
  
    document.getElementById("snackbar").style.color = color;
    document.getElementById("snackbar").style.backgroundColor = this.bgcolor;
    var x = document.getElementById("snackbar");
    x.innerHTML='<span class="colors_icon" style="color:white !important;"></span>'+text;
    x.className = "show";

    setTimeout(()=>{
      this.snack_close();
    },2000); 
   
    
  }

  snack_close() {
    var x = document.getElementById("snackbar");
    x.classList.remove("show");
  }



  // #################    blog  ###############################

  select1(event){
    if(event.target.files.length > 0)
    {
      this.blog1=event.target.files[0];
    }
  }

  blog_update1(){

    const fd= new FormData();
    fd.append('img',this.blog1,this.blog1.name);
    fd.append('heading',this.myForm.get('h1').value);
    fd.append('desc',this.myForm.get('d1').value);
    fd.append('id','1');

    return this.http.upload_blog(fd).subscribe(res=>{
      
      this.snackbar('info','Successfully Updated !!');
      this.myForm.reset();

    });
   

  }

  blog_update2(){

    const fd= new FormData();
    fd.append('img',this.blog1,this.blog1.name);
    fd.append('heading',this.myForm.get('h1').value);
    fd.append('desc',this.myForm.get('d1').value);
    fd.append('id','2');

    return this.http.upload_blog(fd).subscribe(res=>{
      
      this.snackbar('info','Successfully Updated !!');
      this.myForm.reset();

    });
   

  }

  blog_update3(){

    const fd= new FormData();
    fd.append('img',this.blog1,this.blog1.name);
    fd.append('heading',this.myForm.get('h1').value);
    fd.append('desc',this.myForm.get('d1').value);
    fd.append('id','3');

    return this.http.upload_blog(fd).subscribe(res=>{
      
      this.snackbar('info','Successfully Updated !!');
      this.myForm.reset();

    });
   

  }


  
 

}
