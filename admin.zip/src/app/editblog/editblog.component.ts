import { Component, OnInit } from '@angular/core';
import {BlogService} from '../blog/blog.service';
import {Router,ActivatedRoute} from '@angular/router';
import {FormGroup,Validators,FormBuilder} from '@angular/forms';
import { from } from 'rxjs';

@Component({
  selector: 'app-editblog',
  templateUrl: './editblog.component.html',
  styleUrls: ['./editblog.component.css']
})
export class EditblogComponent implements OnInit {

  image_path="http://localhost/Angular_API/uploads/";
  myForm:FormGroup;
  data:any=[];
  image:any=null;
  blogs:any;
  alert:boolean=false;
  constructor(
    private http:BlogService,
    private route:ActivatedRoute,
     private fb:FormBuilder, 
     private router:Router
     ) { }

  ngOnInit() {

   
   
   this.myForm=this.fb.group({
    id:[''],
    h1:['',[Validators.required]],
    d1:['',[Validators.required]],
    bimg1:['']

   });

   var id=this.route.snapshot.params.id;

   return this.http.fetchData(id).subscribe(res=>{
       this.data=res;
      //  console.log(this.data);
      this.myForm.patchValue({
        id:res[0].id,
        h1:res[0].heading,
        d1:res[0].description,
      


      });
      this.image=res[0].img; //set image variable used for view
      // console.log(this.image);
   });

  }

  select1(event){

    if(event.target.files.length > 0)
    {
       this.blogs=event.target.files[0];
       
    }
   
  }

  get id(){return this.myForm.get('id')}
  get h1(){return this.myForm.get('h1')}
  get d1(){return this.myForm.get('d1')}
  get bimg1(){return this.myForm.get('bimg1')}

  blog_add()
  {
    
    

      const fd= new FormData();
      fd.append('img',this.blogs);
      fd.append('id',this.myForm.get('id').value);
      fd.append('h1',this.myForm.get('h1').value);
      fd.append('d1',this.myForm.get('d1').value);
     
 
     return this.http.updateData(fd).subscribe(res=>{
        localStorage.setItem('alert','update');
         this.router.navigate(['/blog']);
     });
      
    
    

  }

}
