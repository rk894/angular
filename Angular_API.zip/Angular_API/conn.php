<?php

$conn=mysqli_connect('localhost','root','','angular') or die('db not connect');

?>