<?php

 
include_once "conn.php";


  header('Access-Control-Allow-Origin: *');
  header('Access-Control-Allow-Methods: GET, POST, PATCH, PUT, DELETE, OPTIONS');
  header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token');

$postdata = json_decode(file_get_contents("php://input"),true);

// print_r($postdata);

if($postdata !='')
{
	 $a=$postdata['id'];
    
    $query=mysqli_query($conn,"delete from demo where id='$postdata'");

    if($query==true)
    {
    	$res="success";
    }
    else
    {
    	$res="fail";
    }

    echo json_encode($res);

}
?>