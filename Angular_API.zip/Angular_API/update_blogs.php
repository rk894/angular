<?php

  header('Access-Control-Allow-Origin: *');
  header('Access-Control-Allow-Methods: GET, POST, PATCH, PUT, DELETE, OPTIONS');
  header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token');
include_once "conn.php";

// print_r($_POST);

// echo $_FILES['img']['name'];


if(isset($_FILES['img']['name']))
{
	$heading=$_POST['h1'];
	$desc=$_POST['d1'];
	$id=$_POST['id'];
	

    
     $newFileName = uniqid('uploaded-', true) 
    . '.' . strtolower(pathinfo($_FILES['img']['name'], PATHINFO_EXTENSION));
   move_uploaded_file($_FILES['img']['tmp_name'], 'uploads/' . $newFileName);
   

   $query1=mysqli_query($conn,"UPDATE blog_details set heading='$heading',description='$desc',img='$newFileName' where id='$id'");

  
   	 $data="success";
  

}
else
{

  $query1=mysqli_query($conn,"UPDATE blog_details set heading='$heading',description='$desc' where id='$id'");

  
     $data="success";

}

 echo json_encode($data);


?>