<?php

  header('Access-Control-Allow-Origin: *');
  header('Access-Control-Allow-Methods: GET, POST, PATCH, PUT, DELETE, OPTIONS');
  header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token');
include_once "conn.php";

$postdata = json_decode(file_get_contents("php://input"),true);

// print_r($postdata);

// die;

$email=$postdata['email'];
$pass=$postdata['pass'];



   $query1=mysqli_query($conn,"SELECT * from login where email='$email' AND password='$pass'");

   $row=mysqli_num_rows($query1);

   if($row == 1)
   {

    $data="success";
   }
   else
   {

     $data="fail";

   }

  
   	
  

 echo json_encode($data);


?>