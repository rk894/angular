<?php

 
include_once "conn.php";


  header('Access-Control-Allow-Origin: *');
  header('Access-Control-Allow-Methods: GET, POST, PATCH, PUT, DELETE, OPTIONS');
  header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token');

$postdata = json_decode(file_get_contents("php://input"),true);

// print_r($postdata);

if(isset($_FILES['img']['name']))
{
   $name=$_POST['name'];
   $email=$_POST['email'];
  
  

    
     $newFileName = uniqid('uploaded-', true) 
    . '.' . strtolower(pathinfo($_FILES['img']['name'], PATHINFO_EXTENSION));
   move_uploaded_file($_FILES['img']['tmp_name'], 'uploads/' . $newFileName);
   

   $query1=mysqli_query($conn,"INSERT into demo values('','$name','$email','$newFileName')");

  
     $data="success";

 echo json_encode($data);

  

}



?>