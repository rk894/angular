<?php


  header('Access-Control-Allow-Origin: *');
  header('Access-Control-Allow-Methods: GET, POST, PATCH, PUT, DELETE, OPTIONS');
  header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token');

include_once "conn.php";

// print_r($_POST);

//  print_r($_FILES['profile']['name']);

 $name= $_POST['name'];



if($name!='')
{

     $newFileName = uniqid('uploaded-', true) 
    . '.' . strtolower(pathinfo($_FILES['profile']['name'], PATHINFO_EXTENSION));
   move_uploaded_file($_FILES['profile']['tmp_name'], 'uploads/' . $newFileName);

   $query1=mysqli_query($conn,"insert into img values('','$name','$newFileName')");

  
   	 $data="success";
  

}









 echo json_encode($data);

// echo json_decode($data);

// echo json_encode(array_map('trim',$data));



// echo json_encode(json_decode($data));

?>