<?php

  header('Access-Control-Allow-Origin: *');
  header('Access-Control-Allow-Methods: GET, POST, PATCH, PUT, DELETE, OPTIONS');
  header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token');
include_once "conn.php";

// print_r($_POST);

// echo $_FILES['img']['name'];


if(isset($_FILES['img']['name']))
{
	$heading=$_POST['heading'];
	$desc=$_POST['desc'];
	$id=$_POST['id'];
	

    
     $newFileName = uniqid('uploaded-', true) 
    . '.' . strtolower(pathinfo($_FILES['img']['name'], PATHINFO_EXTENSION));
   move_uploaded_file($_FILES['img']['tmp_name'], 'uploads/' . $newFileName);
   

   $query1=mysqli_query($conn,"INSERT into blog_details values('','$heading','$desc','$newFileName','0')");

  
   	 $data="success";
  

}

 echo json_encode($data);


?>