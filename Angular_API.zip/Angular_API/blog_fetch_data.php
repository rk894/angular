<?php


  header('Access-Control-Allow-Origin: *');
  header('Access-Control-Allow-Methods: GET, POST, PATCH, PUT, DELETE, OPTIONS');
  header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token');
include_once "conn.php";

 $id=$_GET['id'];

$query=mysqli_query($conn,"select * from blog_details where id='$id'");

$data=array();
foreach($query as $value)
{
	$data[]=$value;
}
 echo json_encode($data);

// echo json_decode($data);

// echo json_encode(array_map('trim',$data));



// echo json_encode(json_decode($data));

?>