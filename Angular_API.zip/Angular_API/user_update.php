<?php

 
  include_once "conn.php";


  header('Access-Control-Allow-Origin: *');
  header('Access-Control-Allow-Methods: GET, POST, PATCH, PUT, DELETE, OPTIONS');
  header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token');


$data = json_decode(file_get_contents("php://input"),true);




// print_r($_GET);

$id=$_GET['id'];


if($id !='')
{
	
   

$query=mysqli_query($conn,"select * from user where id='$id'");

$data=array();
foreach($query as $value)
{
    $data[]=$value;
}
 echo json_encode($data);


}

?>