<?php

// error_reporting(0);

  header('Access-Control-Allow-Origin: *');
  header('Access-Control-Allow-Methods: GET, POST, PATCH, PUT, DELETE, OPTIONS');
  header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token');

include_once "conn.php";

// print_r($_POST);

//  print_r($_FILES['img']['name']);

 $id=$_POST['id'];



if(isset($_FILES['img']['name']))
{
	

     $newFileName = uniqid('uploaded-', true) 
    . '.' . strtolower(pathinfo($_FILES['img']['name'], PATHINFO_EXTENSION));
   move_uploaded_file($_FILES['img']['tmp_name'], 'uploads/' . $newFileName);

   $query1=mysqli_query($conn,"UPDATE slider set img='$newFileName' where id='$id'");

  
   	 $data="success";
  

}

 echo json_encode($data);









// echo json_decode($data);

// echo json_encode(array_map('trim',$data));



// echo json_encode(json_decode($data));

?>