import { TestBed } from '@angular/core/testing';

import { StudnetService } from './studnet.service';

describe('StudnetService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: StudnetService = TestBed.get(StudnetService);
    expect(service).toBeTruthy();
  });
});
