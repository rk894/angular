import { Component, OnInit } from '@angular/core';
import { StudnetService} from '../studnet.service';
import { Router} from '@angular/router';



@Component({
  selector: 'app-show',
  templateUrl: './show.component.html',
  styleUrls: ['./show.component.css']
})
export class ShowComponent implements OnInit {

  data:{};

  constructor(private http:StudnetService, private router: Router) { 

 
   
    // console.log(this.data);

  }

  ngOnInit() {

    this.http.getData().subscribe(data =>this.data=data);
    
  }           

  delete(id)
  {
      //  alert(id);

      if(confirm('Are you sure want to delete !!!'))
      {
        return this.http.deleteData(id).subscribe(res =>{
          this.ngOnInit();
        });
      }
     
      
  }

  edit(id:number)
  {
    this.router.navigate(['edit/'+id]);
  }

}
