import { Injectable } from '@angular/core';
import { HttpClient} from '@angular/common/http';



@Injectable({
  providedIn: 'root'
})
export class StudnetService {

  url="http://localhost/Angular_API/user_insert.php";

  url_fetch="http://localhost/Angular_API/user_fetch.php";

  url_delete="http://localhost/Angular_API/user_delete.php?id=";
  
  url_update="http://localhost/Angular_API/user_update.php?id=";

  url_update_data="http://localhost/Angular_API/user_updatedata.php";

  constructor(private http:HttpClient) { }

  insertData(data)
  { 
    // console.log(data);
    return this.http.post(this.url,data);
  }

  getData()
  {
    
    return this.http.get(this.url_fetch);
  }

  deleteData(id:number)
  {
    // console.log(id);
      return this.http.delete(this.url_delete+id);
  }

  getId(id:number)
  {
    // alert(id);
     return this.http.get(this.url_update+id);
  }

  updateData(data)
  {
    return this.http.post(this.url_update_data,data);
  }
}
