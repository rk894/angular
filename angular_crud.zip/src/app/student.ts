export class Student {

    
}
