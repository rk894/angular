import { Component, OnInit } from '@angular/core';
import { FormGroup,Validators,FormControl,FormBuilder} from '@angular/forms';
import { Router,Params,ActivatedRoute} from '@angular/router';
import { StudnetService} from '../studnet.service';


@Component({
  selector: 'app-edit',
  templateUrl: './edit.component.html',
  styleUrls: ['./edit.component.css']
})
export class EditComponent implements OnInit {
  
  myForm:FormGroup;
  showMsg:any;
  
  constructor(
    private http: StudnetService,
     private fb :FormBuilder, 
     private router: Router,
      private routes:ActivatedRoute
       ) { }

  ngOnInit() {

    this.myForm=this.fb.group({

      id:[''],
      name:['', [Validators.required,Validators.minLength(3)]],
      email:['',[Validators.required,Validators.email]],
      mobile:['',[Validators.required,Validators.minLength(3)]],
      address:['',Validators.required]

    });

    // get id result

    const p=this.routes.snapshot.params;  // it return object
    // alert(p.id);

    this.http.getId(p.id).toPromise().then(res => {
    
      // this.myForm.patchValue(res);
     
      this.myForm.controls.id.setValue(res[0].id);
      this.myForm.controls.name.setValue(res[0].name);
      this.myForm.controls.email.setValue(res[0].email);
      this.myForm.controls.mobile.setValue(res[0].mobile);
      this.myForm.controls.address.setValue(res[0].address);
      // console.log(res[0]);
      // console.log(res[0].id);
      // console.log(res[0].name);
      // console.log(res[0].address);
      // console.log(res);

     // or

      // this.myForm=this.fb.group({

      //   id:[''],
      //   name:res[0].name,
      //   email:res[0].email,
      //   mobile:res[0].mobile,
      //   address:res[0].address
  
      // });


    });
    // console.log(p.id);

  }
  get name() { return this.myForm.get('name')}
  get email() { return this.myForm.get('email')}
  get mobile() { return this.myForm.get('mobile')}
  get address() { return this.myForm.get('address')}


  


  onUpdate()
  {
    // console.log(this.myForm.value);
    
    return this.http.updateData(this.myForm.value).subscribe(res => {
      this.router.navigate(['show']);
    });

  }

}
