import { Component, OnInit } from '@angular/core';
import { FormGroup,Validators,FormControl,FormBuilder} from '@angular/forms';
import {StudnetService} from '../studnet.service';




@Component({
  selector: 'app-form',
  templateUrl: './form.component.html',
  styleUrls: ['./form.component.css']
})
export class FormComponent implements OnInit {


  showMsg: boolean = false;

  

  myForm:FormGroup;

 
  constructor(private fb: FormBuilder, private student: StudnetService ) { }

  ngOnInit() {

   
    this.myForm=this.fb.group({

      name:['', [Validators.required,Validators.minLength(3)]],
      email:['',[Validators.required,Validators.email]],
      mobile:['',[Validators.required,Validators.minLength(3)]],
      address:['',Validators.required]

    });
    
  }

  get name() { return this.myForm.get('name')}
  get email() { return this.myForm.get('email')}
  get mobile() { return this.myForm.get('mobile')}
  get address() { return this.myForm.get('address')}

  onSubmit()
  {
    // console.log(this.myForm.value);
    this.student.insertData(this.myForm.value).subscribe(res=>{
      this.showMsg= true;
      this.myForm.reset();
     

     
      setTimeout(() => {
        this.showMsg= false;
      }, 2000);


    });

    


    }

    
    
    
  }


