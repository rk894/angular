export const environment = {
  production: true,
  apiUrl:"http://localhost/Angular_API/",
};
