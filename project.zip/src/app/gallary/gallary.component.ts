import { Component, OnInit } from '@angular/core';
import {GallaryService} from './gallary.service';

@Component({
  selector: 'app-gallary',
  templateUrl: './gallary.component.html',
  styleUrls: ['./gallary.component.css']
})
export class GallaryComponent implements OnInit {
  
  data:any=[];
  image:string;
  constructor(private http:GallaryService) { }

  ngOnInit() {
    return this.http.fetchData().subscribe(res=>{
      this.data=res;
       this.image=this.http.image_url;
      // console.log(this.data)
    })
  }

}
