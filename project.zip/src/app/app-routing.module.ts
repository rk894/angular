import { NgModule, Component } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {BodyComponent} from './body/body.component';
import { CardComponent} from './card/card.component';
import {FooterComponent} from './footer/footer.component';
import {GallaryComponent} from './gallary/gallary.component';
import {HeaderComponent} from './header/header.component';
import {SliderComponent} from './slider/slider.component';
import {BlogComponent} from './blog/blog.component';
import {ContactComponent} from './contact/contact.component';
import { from } from 'rxjs';


const routes: Routes = [

  {
    path:'',component:BodyComponent, pathMatch:'full'
  },
  {
    path:'blog', component:BlogComponent
  },
  {
    path:'contact',component:ContactComponent
  },
  {
    path:'home',component:BodyComponent
  },
  {
    path:'**', component:BodyComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes, { useHash: true })],
  exports: [RouterModule]
})
export class AppRoutingModule { }
