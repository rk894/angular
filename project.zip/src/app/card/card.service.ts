import { Injectable } from '@angular/core';
import {HttpClient } from  '@angular/common/http';
import {environment} from '../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class CardService {

  url=environment.apiUrl+"blog_select.php";
  image_url=environment.apiUrl+"uploads";

  constructor(private http:HttpClient) { }

  getData()
  {
    return this.http.get(this.url);
  }
}
