import { Component, OnInit } from '@angular/core';
import {CardService} from './card.service';

@Component({
  selector: 'app-card',
  templateUrl: './card.component.html',
  styleUrls: ['./card.component.css']
})
export class CardComponent implements OnInit {

  image_url:string;

  constructor(private http:CardService) { }

  blog_details:any=[];

  ngOnInit() {

    return this.http.getData().subscribe(res=>{

      this.blog_details=res;
      this.image_url=this.http.image_url;
      // console.log(this.blog_details);

    })
  }

}
