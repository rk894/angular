import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {environment} from '../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class ContactService {

  // url = "http://localhost/Angular_API/conatct.php";
  url =environment.apiUrl+"conatct.php";

  constructor(private http:HttpClient) { }

  insert(data)
  {
    return this.http.post(this.url,data);
  }
}
