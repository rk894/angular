import { Component, OnInit } from '@angular/core';
import {FormControl,FormGroup,Validators, FormBuilder} from '@angular/forms';
import {ContactService} from '../contact/contact.service';
// declare var $: any;
import * as $ from 'jquery';

@Component({
  selector: 'app-contact',
  templateUrl: './contact.component.html',
  styleUrls: ['./contact.component.css']
})
export class ContactComponent implements OnInit {

  myForm:FormGroup;
  alert:boolean=false;

  constructor(private http:ContactService,private fb:FormBuilder) { }

  ngOnInit() {
   
   this.myForm=this.fb.group({

    name:['',[Validators.required]],
    email:['',[Validators.required]],
    mobile:['',[Validators.required]]

   });
  }

  get name(){ return this.myForm.get('name').value}
  get email(){ return this.myForm.get('email').value}
  get mobile(){ return this.myForm.get('mobile').value}

  onSubmit()
  {
    
    return this.http.insert(this.myForm.value).subscribe(res=>{
      this.alert=true;
      
      $("#abc").fadeOut(2000);
     
      this.myForm.reset();
      
    })
  }

}
