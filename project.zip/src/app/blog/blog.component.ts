import { Component, OnInit } from '@angular/core';
import {BlogService} from "./blog.service";
import { Router, NavigationEnd } from '@angular/router';


@Component({
  selector: 'app-blog',
  templateUrl: './blog.component.html',
  styleUrls: ['./blog.component.css']
})
export class BlogComponent implements OnInit {

  constructor(private http:BlogService,private router:Router) { }

  blog:any=[];
  img:string;

  ngOnInit() {

    this.router.events.subscribe((evt) => {
      if (!(evt instanceof NavigationEnd)) {
          return;
      }
      window.scrollTo(0, 0)
  });


    return this.http.getData().subscribe(res=>{
      this.blog=res;
      this.img=this.http.img_url;
      // console.log(this.blog);
    });
  }

}
