import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {environment} from '../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class BlogService {

 url=environment.apiUrl+"blog_details.php";

 img_url=environment.apiUrl+"uploads/";

  constructor(private http:HttpClient) { }

  getData()
  {
    return this.http.get(this.url);
  }
}
