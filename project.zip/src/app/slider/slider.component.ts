import { Component, OnInit } from '@angular/core';
import {ImagesService} from './images.service';

@Component({
  selector: 'app-slider',
  templateUrl: './slider.component.html',
  styleUrls: ['./slider.component.css']
})
export class SliderComponent implements OnInit {

  data:any=[];
  baseurl:string;
  show:boolean=true;
  constructor(private http:ImagesService) { }

  ngOnInit() {
    this.baseurl=this.http.baseurl;

    return this.http.getData().subscribe(res=>{

      this.data=res;
    //  console.log(this.data);

    })
  }

}
