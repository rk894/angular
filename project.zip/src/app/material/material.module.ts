import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations'
import {
        MatCheckboxModule,
        MatInputModule,
        MatButtonModule
      } from '@angular/material';



@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    BrowserAnimationsModule,
    MatCheckboxModule,
    MatInputModule,
    MatButtonModule
  ],
  exports: [
    BrowserAnimationsModule,
    MatCheckboxModule,
    MatInputModule,
    MatButtonModule
  ]
})
export class MaterialModule { }
